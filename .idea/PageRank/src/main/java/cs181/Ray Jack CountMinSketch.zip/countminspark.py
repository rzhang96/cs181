#!/usr/bin/env python
import sys
import time
import pyspark
import pyspark.streaming
import countminsketch as cms

def make_CMS(items):
	countmin = cms.CountMinSketch(0.05, 0.05)
	for item in items:
		countmin.increment(item)
	return countmin

def getItems(item,countmin):
	countmin.estimate(item)

def merge(cm1, cm2):
	cm1.merge(cm1, cm2)

def main():
	sc = pyspark.SparkContext("local[2]", "Spark Count Min Sketch")
    ssc = pyspark.streaming.StreamingContext(sc, 1)
    socket_stream = ssc.socketTextStream("127.0.0.1", 5555)
    lines = socket_stream.window(10)
    counts = lines.flatMap(lambda text: text.split(" "))\
                  .map(lambda text: text.encode('utf-8'))\
                  .map(make_CMS)
    print(getItems("#heatwave",counts))

    ssc.start()
    ssc.awaitTermination()

if __name__ == "__main__":
    main()
