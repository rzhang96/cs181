# Ray Zhang, Jack (Jiawei) Huang
import hashlib
import array
import mmh3


class CountMinSketch(object):
	def __init__(self, delta, epsilon):
		self.d = compute_depth(epsilon)
		self.w = compute_width(delta)
		self.cms = [[0 for x in range(self.w)] for y in range(self.d)]

	def compute_depth(eps):
		d = ceil(2/eps)
		return d
	def compute_width(delt):
		w = ceil(log(1./delt))
		return w

	def increment(key):
		for i in range(0, depth):
			index = mmh3.hash(key, i) & self.w
			self.cms[i][index] += 1

	def estimate(key):
		minEst = sys.maxint
		for i in range(0, depth):
			index = mmh3.hash(key, i) & self.w
			if self.cms[i][index] < minEst:
				minEst = self.cms[i][index]
		if minEst = sys.maxint:
			return 0
			else: return minEst

	def merge(cm1, cm2):
		cm3 = [][]
		for i in range(0, self.d):
			for j in range(0, self.w):
				cm3[i][j] = cm1[i,j]+cm2[i][j]
		return cm3